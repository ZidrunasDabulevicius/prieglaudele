-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2022 at 02:17 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prieglauda`
--

-- --------------------------------------------------------

--
-- Table structure for table `gyvunai`
--

CREATE TABLE `gyvunai` (
  `gyvunas_id` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp(),
  `vartotojai_id` int(11) NOT NULL,
  `kategorija_id` int(11) NOT NULL,
  `amzius` float NOT NULL,
  `dokumentai` tinyint(1) NOT NULL,
  `nuotrauka` varchar(254) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gyvunai`
--

INSERT INTO `gyvunai` (`gyvunas_id`, `time`, `vartotojai_id`, `kategorija_id`, `amzius`, `dokumentai`, `nuotrauka`) VALUES
(2, '2022-04-20 11:44:49', 2, 5, 1.5, 0, 'img/1.jpg'),
(3, '2022-04-20 12:14:36', 3, 6, 2.5, 1, 'img/2.jpg'),
(4, '2022-04-20 12:14:48', 2, 7, 4.5, 1, 'img/3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `ivykiai`
--

CREATE TABLE `ivykiai` (
  `ivykiai_id` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp(),
  `vartotojai_id` int(11) NOT NULL,
  `sql_string` varchar(254) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `kategorija`
--

CREATE TABLE `kategorija` (
  `kategorija_id` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp(),
  `vartotojai_id` int(11) NOT NULL,
  `pavadinimas` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategorija`
--

INSERT INTO `kategorija` (`kategorija_id`, `time`, `vartotojai_id`, `pavadinimas`) VALUES
(5, '2022-04-20 11:19:33', 1, 'Šuo'),
(6, '2022-04-20 11:22:47', 1, 'Katė'),
(7, '2022-04-20 11:25:13', 1, 'Kiti'),
(8, '2022-04-20 11:40:03', 1, 'Roplys');

-- --------------------------------------------------------

--
-- Table structure for table `vartotojai`
--

CREATE TABLE `vartotojai` (
  `vartotojai_id` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp(),
  `vardas` varchar(20) NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `vardas_pavarde` varchar(40) NOT NULL,
  `miestas` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `tel` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vartotojai`
--

INSERT INTO `vartotojai` (`vartotojai_id`, `time`, `vardas`, `admin`, `vardas_pavarde`, `miestas`, `email`, `tel`) VALUES
(1, '2022-04-20 10:28:03', 'admin', 1, 'Adminas Adminaitis', 'Vilnius', 'admin@gmail.com', '+370 888 12345'),
(2, '2022-04-20 10:35:23', 'petras', 0, 'Petras Petraitis', 'Kaunas', 'petras@gmail.com', '+370 888 23456'),
(3, '2022-04-20 10:35:41', 'jonas', 0, 'Jonas Jonaitis', 'Palanga', 'jonas@gmail.com', '+370 888 34567');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gyvunai`
--
ALTER TABLE `gyvunai`
  ADD PRIMARY KEY (`gyvunas_id`),
  ADD KEY `vartotojai_id` (`vartotojai_id`),
  ADD KEY `kategorija_id` (`kategorija_id`);

--
-- Indexes for table `ivykiai`
--
ALTER TABLE `ivykiai`
  ADD PRIMARY KEY (`ivykiai_id`),
  ADD KEY `vartotojai_id` (`vartotojai_id`);

--
-- Indexes for table `kategorija`
--
ALTER TABLE `kategorija`
  ADD PRIMARY KEY (`kategorija_id`),
  ADD KEY `vartotojai_id` (`vartotojai_id`);

--
-- Indexes for table `vartotojai`
--
ALTER TABLE `vartotojai`
  ADD PRIMARY KEY (`vartotojai_id`),
  ADD UNIQUE KEY `vardas` (`vardas`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gyvunai`
--
ALTER TABLE `gyvunai`
  MODIFY `gyvunas_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ivykiai`
--
ALTER TABLE `ivykiai`
  MODIFY `ivykiai_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kategorija`
--
ALTER TABLE `kategorija`
  MODIFY `kategorija_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `vartotojai`
--
ALTER TABLE `vartotojai`
  MODIFY `vartotojai_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `gyvunai`
--
ALTER TABLE `gyvunai`
  ADD CONSTRAINT `gyvunai_ibfk_1` FOREIGN KEY (`vartotojai_id`) REFERENCES `vartotojai` (`vartotojai_id`),
  ADD CONSTRAINT `gyvunai_ibfk_2` FOREIGN KEY (`kategorija_id`) REFERENCES `kategorija` (`kategorija_id`);

--
-- Constraints for table `ivykiai`
--
ALTER TABLE `ivykiai`
  ADD CONSTRAINT `ivykiai_ibfk_1` FOREIGN KEY (`vartotojai_id`) REFERENCES `vartotojai` (`vartotojai_id`);

--
-- Constraints for table `kategorija`
--
ALTER TABLE `kategorija`
  ADD CONSTRAINT `kategorija_ibfk_1` FOREIGN KEY (`kategorija_id`) REFERENCES `gyvunai` (`kategorija_id`),
  ADD CONSTRAINT `kategorija_ibfk_2` FOREIGN KEY (`vartotojai_id`) REFERENCES `vartotojai` (`vartotojai_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
